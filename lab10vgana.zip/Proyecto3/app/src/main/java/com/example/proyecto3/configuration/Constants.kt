package com.example.proyecto3.configuration

const val BASE_URL: String = "https://api.giphy.com/v1/gifs/"
const val API_KEY = "Yv5iWWLO1Mz0e5hGhkS91gt6B54KYen5"